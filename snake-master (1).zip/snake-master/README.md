# [Snake](https://youtu.be/baBq5GAL0_U)
- Coding Tutorial: https://youtu.be/baBq5GAL0_U
- Demo: https://imkennyyip.github.io/snake/

In this tutorial, you will learn how to create Snake game from scratch using HTML5 canvas and javascript.

![snake-preview](https://user-images.githubusercontent.com/78777681/163033854-f52af2c6-38f9-419c-a4cc-03b5a7b72703.png)
